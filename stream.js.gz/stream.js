var getUri = require("get-uri");

// getUri("https://www.google.com/",function(err,rs){
//     if (err) throw err;
//     rs.pipe(process.stdout)
// });

console.log(process.argv[1])